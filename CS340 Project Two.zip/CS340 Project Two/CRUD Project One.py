#paloma rodriguez snhu cs340 project one CRUD 9/25/23

from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self):
        USER = 'aacuser' #user / login information created
        PASS = 'SNHU1234' #i kept same, did not change for continuity and making more helpful!
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 31580
        DB = 'aac' #database created / imported
        COL = 'animals'
        #
        # Initialize Connection
        #
        self.client = MongoClient('mongodb://localhost:31580' % (USER,PASS,HOST,PORT))
        self.database = self.client['AAC' % (DB)]
        self.collection = self.database['%s' % (COL)]
        
# Complete this create method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            insertStatus = self.database.animals.insert_one(data) #data should be dictionary
            if insertStatus != 0: #return 
                return False
            return True
        else:
            raise Exception("Nothing to save, because data parameter is empty")           
       
    
# Create method to implement the R in CRUD.
    def read(self,queryData):
        if queryData:
            inputData = self.database.animals.find(queryData, {"_id": False}) #input
        else:
            inputData = self.database.animals.find({}, {"_id": False}) #return
        return inputData
    
# Create method to implement the U in CRUD
    def update(self,inputData, newData):
        if inputData is not None:
            success = self.database.animals.update_many(inputData, {"$set": newData}) #input
        else:
            return "{}" #return 
        return success 
    
# Create method to implement the D in CRUD
    def delete(self, deleteData):
        if deleteData is not None:
            data = self.database.animals.delete_many(deleteData) #input
        else:
            return "{}" #return
        return data
                